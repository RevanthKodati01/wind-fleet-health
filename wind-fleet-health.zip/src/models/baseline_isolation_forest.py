import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import roc_auc_score

PARQUET_DIR = Path("data/processed/scada_parquet")
SPLITS_PATH = Path("data/processed/splits/file_splits.json")
OUT_DIR = Path("models/baseline")
OUT_DIR.mkdir(parents=True, exist_ok=True)

RANDOM_STATE = 42

# caps to keep M3 Air safe
MAX_TRAIN_ROWS = 200_000     # total healthy rows sampled for training per farm
MAX_TEST_ROWS  = 200_000     # total rows sampled for evaluation per farm

def load_feature_cols(sample_file: Path) -> list[str]:
    df = pd.read_parquet(sample_file)
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    # remove obvious non-features
    drop = {"id", "status_type_id"}
    feature_cols = [c for c in num_cols if c not in drop]
    return feature_cols

def sample_healthy_rows(files: list[str], feature_cols: list[str]) -> np.ndarray:
    """
    Stream files and sample healthy rows until we hit MAX_TRAIN_ROWS.
    """
    rng = np.random.default_rng(RANDOM_STATE)
    X_parts = []
    total = 0

    for fname in files:
        df = pd.read_parquet(PARQUET_DIR / fname, columns=feature_cols + ["status_type_id"])
        df = df[df["status_type_id"] == 0]
        if df.empty:
            continue

        remaining = MAX_TRAIN_ROWS - total
        if remaining <= 0:
            break

        # sample at most 'remaining' rows from this file
        if len(df) > remaining:
            take_idx = rng.choice(len(df), size=remaining, replace=False)
            df = df.iloc[take_idx]

        X_parts.append(df[feature_cols].to_numpy(dtype=np.float32, copy=False))
        total += len(df)

    if not X_parts:
        raise RuntimeError("No healthy rows found for training.")
    return np.vstack(X_parts)

def sample_test_rows(files: list[str], feature_cols: list[str]) -> tuple[np.ndarray, np.ndarray]:
    """
    Stream files and sample rows for evaluation until MAX_TEST_ROWS.
    """
    rng = np.random.default_rng(RANDOM_STATE + 1)
    X_parts, y_parts = [], []
    total = 0

    for fname in files:
        df = pd.read_parquet(PARQUET_DIR / fname, columns=feature_cols + ["status_type_id"])
        if df.empty:
            continue

        remaining = MAX_TEST_ROWS - total
        if remaining <= 0:
            break

        if len(df) > remaining:
            take_idx = rng.choice(len(df), size=remaining, replace=False)
            df = df.iloc[take_idx]

        X_parts.append(df[feature_cols].to_numpy(dtype=np.float32, copy=False))
        y_parts.append((df["status_type_id"] != 0).astype(int).to_numpy())
        total += len(df)

    return np.vstack(X_parts), np.concatenate(y_parts)

def main():
    with open(SPLITS_PATH) as f:
        splits = json.load(f)

    for farm, sp in splits.items():
        print(f"\n=== Training IsolationForest for {farm} ===")

        train_files = sp["train"]
        test_files = sp["test"] if len(sp["test"]) > 0 else sp["train"][-5:]

        # pick one file to determine feature columns for this farm
        sample_file = PARQUET_DIR / train_files[0]
        feature_cols = load_feature_cols(sample_file)

        # TRAIN (healthy-only sampled)
        X_train = sample_healthy_rows(train_files, feature_cols)
        print(f"{farm} train samples: {X_train.shape}")

        model = IsolationForest(
            n_estimators=200,
            contamination="auto",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )
        model.fit(X_train)

        # EVAL (sampled)
        X_test, y_test = sample_test_rows(test_files, feature_cols)
        print(f"{farm} test samples: {X_test.shape}, positives={(y_test==1).mean():.3f}")

        scores = -model.score_samples(X_test)
        auc = roc_auc_score(y_test, scores)
        print(f"{farm} ROC-AUC: {auc:.4f}")

        joblib.dump(
            {"model": model, "features": feature_cols},
            OUT_DIR / f"isoforest_{farm}.joblib"
        )

if __name__ == "__main__":
    main()
