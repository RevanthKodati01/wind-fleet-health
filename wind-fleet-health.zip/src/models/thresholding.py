import json
from pathlib import Path
import numpy as np
import pandas as pd
import joblib

PARQUET_DIR = Path("data/processed/scada_parquet")
SPLITS_PATH = Path("data/processed/splits/file_splits.json")
MODEL_DIR = Path("models/baseline")
OUT_PATH = Path("models/baseline/thresholds.json")

# target false alarms: 1 per day
# if sampling is 10-min -> 144 points/day
POINTS_PER_DAY = 144
FALSE_ALARMS_PER_DAY = 1

def load_scores_for_healthy(farm: str, files: list[str], model_pack) -> np.ndarray:
    model = model_pack["model"]
    feats = model_pack["features"]

    scores = []
    for fname in files:
        df = pd.read_parquet(PARQUET_DIR / fname, columns=feats + ["status_type_id"])
        df = df[df["status_type_id"] == 0]
        if df.empty:
            continue
        X = df[feats].to_numpy(dtype=np.float32, copy=False)
        s = -model.score_samples(X)
        scores.append(s)

    if not scores:
        return np.array([], dtype=float)
    return np.concatenate(scores)

def main():
    splits = json.loads(Path(SPLITS_PATH).read_text())
    thresholds = {}

    # quantile for threshold (approx)
    q = 1.0 - (FALSE_ALARMS_PER_DAY / POINTS_PER_DAY)

    for farm, sp in splits.items():
        model_pack = joblib.load(MODEL_DIR / f"isoforest_{farm}.joblib")

        # use train files to estimate healthy distribution (safe)
        healthy_scores = load_scores_for_healthy(farm, sp["train"], model_pack)

        if healthy_scores.size == 0:
            print(f"{farm}: no healthy scores found, skipping")
            continue

        thr = float(np.quantile(healthy_scores, q))
        thresholds[farm] = {
            "threshold": thr,
            "false_alarms_per_day_target": FALSE_ALARMS_PER_DAY,
            "points_per_day_assumed": POINTS_PER_DAY,
            "quantile": q,
            "n_scores": int(healthy_scores.size)
        }
        print(f"{farm}: threshold={thr:.4f} (q={q:.6f}, n={healthy_scores.size})")

    OUT_PATH.write_text(json.dumps(thresholds, indent=2))
    print("Saved:", OUT_PATH)

if __name__ == "__main__":
    main()
